/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Entities;

/**
 *
 * @author sibrahim
 */

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainEntity {

public static void main(String[] args) {
    
EntityManagerFactory entityManagerFactory = 
Persistence.createEntityManagerFactory("com.mycompany_AppMaven1_jar_1.0-SNAPSHOTPU");
       
EntityManager entityManager = entityManagerFactory.createEntityManager();
entityManager.getTransaction().begin();

    Department d1 = new Department();
    d1.setName("Information Technology");
    entityManager.persist(d1);
    
    Department d2 = new Department();    
    d2.setName("Human Resources");
    entityManager.persist(d2);
 
     Employee e1 = new Employee();
    e1.setName("Saada Ibrahim");
    //e1.setDeptID((long)1);
    e1.setDept(d1);
    e1.setSalary(2000);    
    entityManager.persist(e1);
    
    Employee e2 = new Employee();
    e2.setName("Tony Ibrahim");
    e2.setDept(d1);
    e2.setSalary(3000);    
    entityManager.persist(e2);   

    Employee e3 = new Employee();
    e3.setName("Najib Moussallem");
    e3.setDept(d2);
    e3.setSalary(3000);    
    entityManager.persist(e3);
    
    Employee e4 = new Employee();
    e4.setName("Angelo Moussallem");
    e4.setDept(d2);
    e4.setSalary(3000);    
    entityManager.persist(e4);
    
entityManager.getTransaction().commit();
entityManager.close();
entityManagerFactory.close();

    }
    
}  
